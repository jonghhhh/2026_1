# llm.py
# ───────────────────────────────────────────────────────────────────────────
# Gemini 2.5 Flash-Lite 호출 래퍼. 모델명만 한 줄 바꾸면 다른 모델로 교체 가능.
# 스트리밍(generate_content_stream)을 쓰는 이유: 응답이 한 글자씩 흘러나와
# 참여자 이탈을 줄인다(Simple Chat 논문이 강조한 원칙).
# ───────────────────────────────────────────────────────────────────────────
import os
from dotenv import load_dotenv
from google import genai
from google.genai import types

load_dotenv()  # 로컬: .env 읽음 / HF Spaces: 무시되고 환경변수에서 직접 읽음

API_KEY = os.getenv("GEMINI_API_KEY")
if not API_KEY:
    raise RuntimeError(
        "GEMINI_API_KEY가 설정되지 않았습니다. "
        "로컬은 .env, Spaces는 Settings → Repository secrets에 등록하세요."
    )

MODEL_NAME = "gemini-2.5-flash-lite"  # ← 모델 교체 지점 (한 줄)
client = genai.Client(api_key=API_KEY)


def _to_gemini(messages):
    """Streamlit 내부 메시지 → Gemini 포맷 변환.
    Gemini는 role이 'user'와 'model'만 허용한다('assistant' 아님)."""
    return [
        {"role": "model" if m["role"] == "assistant" else "user",
         "parts": [{"text": m["content"]}]}
        for m in messages
    ]


def stream_response(system_prompt, messages, temperature=0.7):
    """응답을 청크 단위로 yield하는 제너레이터."""
    config = types.GenerateContentConfig(
        system_instruction=system_prompt,  # 시스템 프롬프트는 매 호출마다 주입
        temperature=temperature,
    )
    stream = client.models.generate_content_stream(
        model=MODEL_NAME,
        contents=_to_gemini(messages),
        config=config,
    )
    for chunk in stream:
        if chunk.text:
            yield chunk.text
