# analyze.py
# ───────────────────────────────────────────────────────────────────────────
# 구글시트(또는 다운로드한 CSV) → 조건별 비교 분석.
# DB가 없으므로 CSV 3개를 직접 읽는다. long-format이라 pivot 한 번이면 끝.
# ───────────────────────────────────────────────────────────────────────────
import pandas as pd
from scipy import stats

# 구글시트에서 받은(혹은 사이드바에서 내려받은) CSV 3개
participants = pd.read_csv("participants.csv")
messages = pd.read_csv("messages.csv")
surveys = pd.read_csv("surveys.csv")

# 1) 완료자만
done = participants[participants["completed"] == 1]
print(f"완료자: {len(done)}명")
print(done["condition"].value_counts())

# 2) 사후 설문을 wide format으로 (한 문항=한 열)
post = surveys[surveys["phase"] == "post"]
post_wide = post.pivot_table(index="participant_id", columns="question_id",
                             values="answer", aggfunc="first")

# 3) 조건과 합치기
df = done[["participant_id", "condition"]].merge(post_wide, on="participant_id")
numeric = ["usefulness", "warmth", "competence", "trust", "clarity", "recommend"]
for c in numeric:
    df[c] = pd.to_numeric(df[c], errors="coerce")

# 4) 조건별 t-test
print("\n=== 조건별 비교 (A: 분석가형, B: 멘토형) ===")
for var in numeric:
    a = df[df["condition"] == "A"][var].dropna()
    b = df[df["condition"] == "B"][var].dropna()
    if len(a) > 1 and len(b) > 1:
        t, p = stats.ttest_ind(a, b)
        print(f"{var:12s}: A={a.mean():.2f}, B={b.mean():.2f}, t={t:+.2f}, p={p:.3f}")
