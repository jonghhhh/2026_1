---
title: 뉴스 기반 팩트체크
emoji: 🔎
colorFrom: blue
colorTo: indigo
sdk: streamlit
sdk_version: 1.40.0
app_file: app.py
pinned: false
---

# 🔎 뉴스 기반 팩트체크 (LangGraph + 네이버 뉴스 + Gemini)

주장 하나를 입력하면 **4단계 워크플로우**가 순서대로 흐르며 진위를 판정합니다.

```
[START] → 검색어 추출 → 네이버 뉴스 검색 → 근거 요약 → 진위 판정 → [END]
```

LLM의 '기억'이 아니라 **최신 뉴스**를 근거로 삼는 것이 핵심입니다(RAG의 기본 아이디어).

## 배포 방법 (Hugging Face Spaces)

1. **Space 생성**: SDK는 `Streamlit` 선택.
2. **파일 업로드**: 이 폴더의 `app.py`, `requirements.txt`, `README.md`를 올립니다.
   - `README.md` 맨 위의 메타데이터(`---` 블록)가 Space 설정으로 인식됩니다.
   - 진입점은 `app_file: app.py` 입니다.
3. **Secrets 등록**: Space의 **Settings → Repository secrets** 에 아래 3개를 추가합니다.

   | 이름 | 설명 |
   |------|------|
   | `GEMINI_API_KEY` | Google AI Studio에서 발급한 Gemini API 키 |
   | `NAVER_CLIENT_ID` | 네이버 개발자센터 검색 API 클라이언트 ID |
   | `NAVER_CLIENT_SECRET` | 네이버 검색 API 클라이언트 시크릿 |

   Secrets에 넣은 값은 코드에서 `os.environ`으로 읽힙니다.

## 로컬에서 실행하기

```bash
pip install -r requirements.txt
# 같은 폴더에 .env 파일을 만들고 위 3개 키를 적은 뒤:
streamlit run app.py
```

`.env` 예시:

```
GEMINI_API_KEY=...
NAVER_CLIENT_ID=...
NAVER_CLIENT_SECRET=...
```
