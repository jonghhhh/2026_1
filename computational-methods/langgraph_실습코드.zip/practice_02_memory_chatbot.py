# ============================================================
# 실습 2: 성격 있는 메모리 챗봇 (난이도: ★★☆)
# ============================================================
#
# [연결 이론] 이론 강의 2장 "에이전트의 기억 (Memory)"
#            이론 강의 1장 "챗봇의 한계② — 기억하지 못한다" 해결
# [연결 실습] LangGraph 실습 강의 8장 "메모리(Memory) 구현"
#
# 목표:
#   - MemorySaver + thread_id로 멀티턴 대화 기억 구현
#   - 시스템 메시지로 챗봇에 성격(역할) 부여
#   - 4턴 이상의 대화에서 기억이 유지되는지 확인
#
# 그래프 구조 (단순하지만 메모리가 핵심):
#   [START] → [chatbot] → [END]
#              ↑ MemorySaver가 매 턴마다 상태를 저장/복원
# ============================================================


# ── 환경 설정 ──────────────────────────────────────────────
import os
from dotenv import load_dotenv
load_dotenv()

# ★ 수정 1: GOOGLE_API_KEY와 GEMINI_API_KEY가 동시에 설정되면
#   "Both GOOGLE_API_KEY and GEMINI_API_KEY are set. Using GOOGLE_API_KEY."
#   경고가 출력된다. 원인: langchain-google-genai가 두 키를 모두 감지할 때 발생.
#   해결: GEMINI_API_KEY 값을 GOOGLE_API_KEY로 복사한 뒤,
#         GEMINI_API_KEY 환경변수를 제거하여 중복을 없앤다.
if os.environ.get("GEMINI_API_KEY") and not os.environ.get("GOOGLE_API_KEY"):
    os.environ["GOOGLE_API_KEY"] = os.environ["GEMINI_API_KEY"]
os.environ.pop("GEMINI_API_KEY", None)   # 중복 키 제거

# ★ 수정 2: LangSmith 추적 비활성화
#   "Failed to POST https://api.smith.langchain.com/runs/multipart ... 403 Forbidden"
#   원인: LANGCHAIN_TRACING_V2 환경변수가 기본 활성화된 경우 LangSmith 서버에
#         실행 기록을 전송하려 하지만, API 키가 없거나 권한이 없을 때 403이 발생.
#   해결: 추적을 명시적으로 끈다.
os.environ["LANGCHAIN_TRACING_V2"] = "false"

print("✅ 환경 설정 완료\n")


# ── 패키지 임포트 ──────────────────────────────────────────
from langgraph.graph import StateGraph, MessagesState, START, END
from langgraph.checkpoint.memory import MemorySaver
from langchain_google_genai import ChatGoogleGenerativeAI


# ============================================================
# 1단계: LLM(두뇌) 초기화
# ============================================================
# 이론 강의 2장: "에이전트의 두뇌는 LLM이다"
# temperature=0.7: 적당히 창의적인 응답 (0=일관적, 1=매우 창의적)
llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash-lite",
    temperature=0.7
)


# ============================================================
# 2단계: 챗봇 노드 정의
# ============================================================
# MessagesState를 사용하면 messages 리스트가 자동으로 누적된다
# → 이전 대화 내역이 모두 LLM에게 전달됨
# → LLM이 맥락을 파악하여 답변할 수 있음
def chatbot(state: MessagesState) -> dict:
    # state["messages"]에는 지금까지의 전체 대화 내역이 들어 있다
    # (시스템 메시지 + 사용자 메시지들 + AI 응답들)
    response = llm.invoke(state["messages"])
    return {"messages": [response]}


# ============================================================
# 3단계: 그래프 조립 + MemorySaver 장착
# ============================================================

graph = StateGraph(MessagesState)
graph.add_node("chatbot", chatbot)
graph.add_edge(START, "chatbot")
graph.add_edge("chatbot", END)

# ★ 핵심: MemorySaver를 checkpointer로 지정
# 이론 강의 2장: "단기 기억 = 회의 중 화이트보드"
# MemorySaver는 각 대화 턴의 상태를 메모리에 자동 저장한다
# → 같은 thread_id로 다시 호출하면 이전 대화가 복원됨
memory = MemorySaver()
app = graph.compile(checkpointer=memory)

print("✅ 메모리 챗봇 그래프 컴파일 완료\n")


# ============================================================
# 4단계: 대화 실행 헬퍼 함수
# ============================================================
def chat(user_message: str, config: dict, turn: int) -> str:
    """
    사용자 메시지를 보내고 AI 응답을 받는 편의 함수.

    Args:
        user_message: 사용자가 입력한 텍스트
        config: thread_id가 포함된 설정 딕셔너리
        turn: 현재 대화 턴 번호 (출력용)

    Returns:
        AI의 응답 텍스트
    """
    result = app.invoke(
        {"messages": [{"role": "user", "content": user_message}]},
        config=config
    )
    ai_reply = result["messages"][-1].content
    print(f"[턴 {turn}]")
    print(f"  👤 사용자: {user_message}")
    print(f"  🤖 AI: {ai_reply}")
    print()
    return ai_reply


# ============================================================
# 5단계: 테스트 A — 유머러스한 과학 해설사 챗봇
# ============================================================
print("=" * 70)
print("🧪 테스트 A: 유머러스한 과학 해설사 (4턴 대화)")
print("=" * 70)

# thread_id: 이 대화방의 고유 식별자
# 같은 thread_id = 같은 채팅방 = 이전 대화 기억
config_a = {"configurable": {"thread_id": "science-teacher-001"}}

# 첫 대화에 시스템 메시지를 포함하면 챗봇의 "성격"이 설정된다
# 이후 대화에서는 시스템 메시지 없이도 이 성격이 유지된다
first_result = app.invoke(
    {"messages": [
        # 시스템 메시지: 챗봇의 역할과 성격을 지정
        {"role": "system", "content":
            "너는 유머러스한 과학 해설사야. "
            "모든 설명에 재미있는 비유를 하나씩 포함해. "
            "말투는 친근하고 반말을 써. "
            "답변은 3문장 이내로 짧게 해."
        },
        {"role": "user", "content": "안녕! 내 이름은 민수야. 블랙홀이 뭐야?"}
    ]},
    config=config_a
)
print("[턴 1]")
print(f"  👤 사용자: 안녕! 내 이름은 민수야. 블랙홀이 뭐야?")
print(f"  🤖 AI: {first_result['messages'][-1].content}")
print()

# 턴 2: 이전 대화를 기억하는지 확인
chat("그럼 블랙홀 안에 들어가면 어떻게 돼?", config_a, 2)

# 턴 3: 내 이름을 기억하는지 확인
chat("내 이름이 뭐라고 했지?", config_a, 3)

# 턴 4: 이전 주제를 이어서 질문
chat("아까 블랙홀 얘기했잖아. 그거랑 비슷한 천체 현상 하나만 더 알려줘.", config_a, 4)


# ============================================================
# 6단계: 테스트 B — 다른 thread_id = 독립된 대화
# ============================================================
print("\n" + "=" * 70)
print("🧪 테스트 B: 다른 thread_id는 이전 대화를 모른다")
print("=" * 70)

# 다른 thread_id → 완전히 새로운 대화 (민수를 모름)
config_b = {"configurable": {"thread_id": "different-room-002"}}

result_b = app.invoke(
    {"messages": [
        {"role": "system", "content": "너는 친절한 도우미야. 답변은 2문장 이내로."},
        {"role": "user", "content": "내 이름 아는?"}
    ]},
    config=config_b
)
print("[독립 대화]")
print(f"  👤 사용자: 내 이름 아는?")
print(f"  🤖 AI: {result_b['messages'][-1].content}")
print()
print("  → 다른 thread_id이므로 '민수'를 모르는 것이 정상!")


# ============================================================
# 7단계: 테스트 C — thread_id A로 돌아가면 기억이 살아 있다
# ============================================================
print("\n" + "=" * 70)
print("🧪 테스트 C: 원래 thread_id로 돌아가면 기억 유지")
print("=" * 70)

# config_a로 다시 돌아감 → 이전 4턴의 대화를 기억!
chat("우리 처음에 무슨 얘기했었지?", config_a, 5)


# ============================================================
# 학습 포인트 정리
# ============================================================
print("=" * 70)
print("""
📝 이 실습에서 배운 것:

1. MemorySaver + thread_id 조합으로 대화 기억을 구현한다.
   - 같은 thread_id → 이전 대화 내역이 자동 복원
   - 다른 thread_id → 완전히 독립된 새 대화

2. 시스템 메시지(role: "system")로 챗봇의 성격을 설정한다.
   - 첫 대화에만 넣으면, 이후 대화에서도 성격이 유지됨
   - MemorySaver가 시스템 메시지도 함께 저장하기 때문

3. thread_id는 카카오톡의 "채팅방"과 같은 개념이다.
   - 채팅방 A에서 한 대화는 채팅방 B에서 보이지 않음
   - 채팅방 A로 다시 돌아오면 이전 대화가 그대로 있음

4. 이론 강의 2장의 "단기 기억"이
   LangGraph에서는 MemorySaver + thread_id로 구현된다.
""")
print("=" * 70)
