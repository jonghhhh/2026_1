# ── 필요한 패키지 설치 ─────────────────────────────────────
# pip install langgraph
# ============================================================
# 실습 1: 시간대별 인사봇 (난이도: ★☆☆)
# ============================================================
#
# [연결 이론] 이론 강의 6장 패턴 ③ Routing Workflow (분기)
# [연결 실습] LangGraph 실습 강의 5장 
#
# 목표:
#   - 시각(hour)에 따라 아침/오후/저녁 인사를 생성하는 그래프
#   - add_conditional_edges와 라우팅 함수를 직접 작성
#
# 그래프 구조:
#   [START] → [check_time] → (아침?) → [morning_greet]  → [END]
#                            (오후?) → [afternoon_greet] → [END]
#                            (저녁?) → [evening_greet]   → [END]
# ============================================================


# ── 패키지 임포트 ──────────────────────────────────────────
from langgraph.graph import StateGraph, START, END
from typing import TypedDict, Literal


# ============================================================
# 1단계: 상태(State) 정의
# ============================================================
# 이론 강의 2장: 에이전트의 기억 = 그래프 전체에서 공유하는 데이터
# TypedDict로 "이 그래프에서 어떤 데이터가 오가는지" 선언한다
# TypedDict: "키 이름과 값의 타입이 정해진 딕셔너리"를 정의하는 문법.
#            실제로는 평범한 dict이지만, 어떤 키가 있어야 하는지 미리 약속해 둔다.
class GreetState(TypedDict):
    name: str            # 사용자 이름 (예: "민수")
    hour: int            # 현재 시각, 0~23 사이의 정수
    time_of_day: str     # 시간대 분류 결과: "morning" / "afternoon" / "evening"
    greeting: str        # 최종 인사말


# ============================================================
# 2단계: 노드(Node) 정의 — 각 작업 단계를 함수로 작성
# ============================================================

# ── 노드 1: 시간대 판별 ────────────────────────────────────
# 이론 강의 6장: 워크플로우에서 "판단" 역할을 하는 노드
# hour 값을 보고 아침/오후/저녁으로 분류한다
def check_time(state: GreetState) -> dict:
    hour = state["hour"]

    if 5 <= hour < 12:
        # 오전 5시 ~ 11시 → 아침
        time_of_day = "morning"
    elif 12 <= hour < 18:
        # 오후 12시 ~ 17시 → 오후
        time_of_day = "afternoon"
    else:
        # 오후 18시 ~ 새벽 4시 → 저녁
        time_of_day = "evening"

    print(f"  [check_time] {hour}시 → {time_of_day}으로 판별")
    # ★ 노드는 "바뀐 키만" 딕셔너리로 반환한다. 상태 전체를 돌려줄 필요 없음.
    #   LangGraph가 이 결과를 기존 state에 자동으로 합쳐(merge) 준다.
    #   여기서는 time_of_day만 갱신되고 name/hour/greeting은 그대로 유지됨.
    return {"time_of_day": time_of_day}


# ── 노드 2a: 아침 인사 ────────────────────────────────────
def morning_greet(state: GreetState) -> dict:
    name = state["name"]
    greeting = f"🌅 좋은 아침이에요, {name}님! 오늘도 활기찬 하루 보내세요."
    print(f"  [morning_greet] 아침 인사 생성 완료")
    return {"greeting": greeting}


# ── 노드 2b: 오후 인사 ────────────────────────────────────
def afternoon_greet(state: GreetState) -> dict:
    name = state["name"]
    greeting = f"☀️ 좋은 오후입니다, {name}님! 남은 일과도 파이팅이에요."
    print(f"  [afternoon_greet] 오후 인사 생성 완료")
    return {"greeting": greeting}


# ── 노드 2c: 저녁 인사 ────────────────────────────────────
def evening_greet(state: GreetState) -> dict:
    name = state["name"]
    greeting = f"🌙 좋은 저녁이에요, {name}님! 오늘 하루도 수고하셨습니다."
    print(f"  [evening_greet] 저녁 인사 생성 완료")
    return {"greeting": greeting}


# ============================================================
# 3단계: 라우팅 함수 — 조건부 분기의 핵심
# ============================================================
# 이론 강의 6장 패턴②: "입력의 종류에 따라 다른 경로로 분기"
# 이 함수의 반환값이 "다음에 실행할 노드의 이름"이 된다
#
# Literal 타입 힌트: 반환값이 이 3가지 중 하나임을 명시
# → LangGraph가 그래프 구성 시 유효성을 검증해 줌
# 반환 타입의 -> Literal[...] 부분: "이 함수는 이 셋 중 하나의 '문자열'만 돌려준다"는 약속.
#   이 문자열들은 우연이 아니라 add_node로 등록한 노드 이름과 정확히 일치해야 한다.
def route_by_time(state: GreetState) -> Literal["morning_greet", "afternoon_greet", "evening_greet"]:
    time_of_day = state["time_of_day"]

    if time_of_day == "morning":
        return "morning_greet"       # → morning_greet 노드로 이동
    elif time_of_day == "afternoon":
        return "afternoon_greet"     # → afternoon_greet 노드로 이동
    else:
        return "evening_greet"       # → evening_greet 노드로 이동


# ============================================================
# 4단계: 그래프 조립 — 노드와 엣지를 연결
# ============================================================
# 이 과정은 "지하철 노선도를 그리는 것"과 같다

graph = StateGraph(GreetState)

# ① 노드 등록 (역 만들기)
graph.add_node("check_time", check_time)
graph.add_node("morning_greet", morning_greet)
graph.add_node("afternoon_greet", afternoon_greet)
graph.add_node("evening_greet", evening_greet)

# ② 엣지 연결 (선로 깔기)
graph.add_edge(START, "check_time")  # 출발역 → check_time

# ★ 핵심: 조건부 엣지 — check_time 실행이 끝나면 route_by_time을 호출하고,
#   그 함수가 돌려준 "문자열 == 노드 이름"으로 다음 노드를 결정한다.
#   (add_edge는 무조건 한 곳으로, add_conditional_edges는 상황에 따라 여러 곳으로)
graph.add_conditional_edges("check_time", route_by_time)

# 각 인사 노드에서 종착역으로
graph.add_edge("morning_greet", END)
graph.add_edge("afternoon_greet", END)
graph.add_edge("evening_greet", END)

# ③ 컴파일 (노선도 완성 → 실제 운행 시작)
app = graph.compile()


# ============================================================
# 5단계: 테스트 — 다양한 시간대로 실행
# ============================================================
# 각 테스트 케이스: (이름, 시각, 기대 시간대)
test_cases = [
    ("민수", 7,  "아침"),    # 오전 7시
    ("지영", 9,  "아침"),    # 오전 9시
    ("철수", 13, "오후"),    # 오후 1시
    ("영희", 17, "오후"),    # 오후 5시
    ("동현", 20, "저녁"),    # 저녁 8시
    ("수진", 2,  "저녁"),    # 새벽 2시 (저녁으로 분류)
]

print("=" * 60)
print("🧪 테스트 실행:")
print("=" * 60)

for name, hour, expected in test_cases:
    print(f"\n▶ 입력: name='{name}', hour={hour}시 (기대: {expected})")

    # invoke(초기상태 딕셔너리): START부터 END까지 그래프를 한 번 실행하고
    #   END에 도달했을 때의 "최종 상태 딕셔너리"를 result로 돌려준다.
    # 초기 상태에서 time_of_day와 greeting은 아직 비어 있음 (노드들이 채워 줄 자리)
    result = app.invoke({
        "name": name,
        "hour": hour,
        "time_of_day": "",   # check_time 노드가 채울 것
        "greeting": "",      # 인사 노드가 채울 것
    })

    print(f"  결과: {result['greeting']}")
    print(f"  분류: {result['time_of_day']}")
    print("-" * 60)


# ============================================================
# 학습 포인트 정리
# ============================================================
print("""
📝 이 실습에서 배운 것:

1. add_conditional_edges를 사용하면
   하나의 노드에서 여러 경로로 분기할 수 있다.

2. 라우팅 함수는 "다음 노드의 이름 문자열"을 반환해야 한다.
   이것이 그래프의 흐름을 결정한다.

3. Literal 타입 힌트는 가능한 반환값을 명시하여
   LangGraph가 그래프의 유효성을 검증하게 한다.

4. 이론 강의 6장의 "조건부 분기 패턴"이
   LangGraph에서는 add_conditional_edges + 라우팅 함수로 구현된다.
""")
