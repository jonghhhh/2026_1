# ============================================================
# 실습 3: 멀티 도구 ReAct 에이전트 (난이도: ★★★)
# ============================================================
#
# [연결 이론] 이론 강의 4장 "ReAct 루프" (Thought → Action → Observation)
#            이론 강의 5장 "Function Calling — 도구 호출의 원리"
# [연결 실습] LangGraph 실습 강의 7장 "도구(Tool)와 ReAct 에이전트"
#
# 목표:
#   - 3개의 도구(뉴스 검색, 번역, 요약)를 정의
#   - create_react_agent로 ReAct 에이전트 생성
#   - LLM이 스스로 도구를 선택·조합하여 복잡한 요청을 처리하는지 확인
#   - ReAct 루프(Thought → Action → Observation 반복)를 추적
#
# 핵심 확인 사항:
#   "AI 관련 뉴스를 찾아서 영어로 번역해줘"
#   → search_news 호출 → translate 호출 → 최종 답변
#   → LLM이 도구를 2번 연속 호출하는 ReAct 루프 확인
# ============================================================


# ── 환경 설정 ──────────────────────────────────────────────
import os
from dotenv import load_dotenv
load_dotenv()
os.environ["GOOGLE_API_KEY"] = os.environ["GEMINI_API_KEY"]
print("✅ 환경 설정 완료\n")


# ── 패키지 임포트 ──────────────────────────────────────────
from langchain_core.tools import tool
from langchain_google_genai import ChatGoogleGenerativeAI
from langgraph.prebuilt import create_react_agent


# ============================================================
# 1단계: 도구(Tool) 3개 정의
# ============================================================
# 이론 강의 5장 핵심:
#   - @tool 데코레이터로 일반 함수를 "LLM이 호출 가능한 도구"로 변환
#   - 독스트링("""...""")이 LLM의 도구 사용 설명서 역할
#   - 독스트링이 부실하면 LLM이 잘못된 도구를 선택한다

# ── 도구 1: 뉴스 검색 ─────────────────────────────────────
@tool
def search_news(topic: str) -> str:
    """주어진 주제에 대한 최신 뉴스 헤드라인 3개를 검색합니다.
    Args:
        topic: 검색할 뉴스 주제 (예: 'AI', '경제', '스포츠', '정치', '기술')
    Returns:
        관련 뉴스 헤드라인 3개를 포함한 문자열
    """
    # 실제로는 뉴스 API를 호출하겠지만, 여기서는 가상 데이터 사용
    news_database = {
        "AI": (
            "1) AI 에이전트 시장 규모 2030년까지 525억 달러 전망\n"
            "2) 구글, Gemini 2.5 모델 공개… 멀티모달 성능 대폭 향상\n"
            "3) 국내 기업 57%가 AI 에이전트 도입 완료"
        ),
        "경제": (
            "1) 한국은행 기준금리 3.25% 동결 결정\n"
            "2) 코스피 3,050선 돌파, 반도체주 강세\n"
            "3) 6월 수출 전년 대비 12.5% 증가"
        ),
        "스포츠": (
            "1) 손흥민 시즌 20호골 달성, 팀 내 득점왕\n"
            "2) 류현진 복귀전 7이닝 1실점 호투\n"
            "3) 2026 밀라노 동계올림픽 한국 선수단 120명 확정"
        ),
        "기술": (
            "1) 삼성전자 3나노 2세대 공정 양산 시작\n"
            "2) 네이버 하이퍼클로바X 기업용 서비스 출시\n"
            "3) 전기차 배터리 에너지 밀도 400Wh/kg 돌파"
        ),
        "정치": (
            "1) 국회 AI 기본법 본회의 통과\n"
            "2) 디지털 플랫폼 규제법 시행 임박\n"
            "3) 공정거래위원회 빅테크 시장 지배력 조사 착수"
        ),
    }

    result = news_database.get(topic)
    if result:
        return f"[{topic} 최신 뉴스]\n{result}"
    else:
        # 정확히 일치하지 않으면 키워드로 부분 검색 시도
        for key, value in news_database.items():
            if topic.lower() in key.lower() or key.lower() in topic.lower():
                return f"[{key} 최신 뉴스]\n{value}"
        return f"'{topic}' 관련 뉴스를 찾지 못했습니다. 다른 주제로 검색해 보세요."


# ── 도구 2: 번역 ──────────────────────────────────────────
@tool
def translate(text: str, target_lang: str) -> str:
    """텍스트를 지정된 언어로 번역합니다.
    Args:
        text: 번역할 원본 텍스트
        target_lang: 번역 대상 언어 (예: 'english', 'japanese', 'chinese', 'korean')
    Returns:
        번역된 텍스트
    """
    # 실제로는 번역 API를 호출하겠지만, 여기서는 간단한 매핑 사용
    # (실습의 핵심은 "LLM이 도구를 연쇄 호출하는 구조"를 이해하는 것)

    # 한국어 → 영어 간이 번역 테이블
    ko_to_en = {
        "AI 에이전트": "AI Agent",
        "시장 규모": "market size",
        "전망": "forecast",
        "구글": "Google",
        "모델 공개": "model released",
        "성능 대폭 향상": "significant performance improvement",
        "국내 기업": "domestic companies",
        "도입 완료": "adoption completed",
        "기준금리": "benchmark interest rate",
        "동결 결정": "freeze decision",
        "수출": "exports",
        "증가": "increase",
    }

    target = target_lang.lower()

    if target in ["english", "영어", "en"]:
        # 간이 번역: 알려진 단어만 치환, 나머지는 원문 유지
        translated = text
        for ko, en in ko_to_en.items():
            translated = translated.replace(ko, en)
        return f"[번역 결과 (→ English)]\n{translated}"
    elif target in ["japanese", "일본어", "ja"]:
        return f"[번역 결과 (→ 日本語)]\n(일본어 번역 시뮬레이션)\n원문: {text[:100]}..."
    elif target in ["chinese", "중국어", "zh"]:
        return f"[번역 결과 (→ 中文)]\n(중국어 번역 시뮬레이션)\n원문: {text[:100]}..."
    else:
        return f"[번역 결과 (→ {target_lang})]\n(번역 시뮬레이션)\n원문: {text[:100]}..."


# ── 도구 3: 텍스트 요약 ────────────────────────────────────
@tool
def summarize_text(text: str) -> str:
    """긴 텍스트를 핵심 내용 중심으로 짧게 요약합니다.
    Args:
        text: 요약할 원본 텍스트
    Returns:
        2~3문장으로 요약된 텍스트
    """
    # 간단한 요약 로직: 줄 단위로 핵심 키워드 추출
    lines = [line.strip() for line in text.split("\n") if line.strip()]

    # 번호가 붙은 항목들을 키워드로 추출
    keywords = []
    for line in lines:
        # "1) AI 에이전트 시장..." 같은 형태에서 핵심 부분 추출
        if ")" in line:
            content = line.split(")", 1)[-1].strip()
            # 첫 10글자를 키워드로 사용
            keywords.append(content[:15] + "...")
        else:
            keywords.append(line[:20] + "...")

    if keywords:
        summary = f"총 {len(keywords)}개 항목의 요약: " + ", ".join(keywords[:3])
        return f"[요약 결과]\n{summary}"
    else:
        return f"[요약 결과]\n원문 ({len(text)}자)의 핵심: {text[:50]}..."


print("✅ 도구 3개 정의 완료: search_news, translate, summarize_text\n")


# ============================================================
# 2단계: ReAct 에이전트 생성
# ============================================================
# 이론 강의 4장: ReAct = Reasoning(추론) + Acting(행동)
# create_react_agent가 내부적으로 다음 루프를 구성한다:
#   ① LLM이 생각한다 (Thought)
#   ② 도구를 호출한다 (Action)
#   ③ 결과를 관찰한다 (Observation)
#   ④ 더 할 일이 있으면 ①로 돌아간다

llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash-lite")
tools = [search_news, translate, summarize_text]

# 한 줄로 ReAct 에이전트 완성!
agent = create_react_agent(llm, tools)

print("✅ ReAct 에이전트 생성 완료\n")


# ============================================================
# 3단계: 대화 결과를 보기 좋게 출력하는 헬퍼 함수
# ============================================================
def run_agent(query: str, test_name: str):
    """
    에이전트에게 요청을 보내고, ReAct 루프의 전체 과정을 출력한다.
    이론 강의 10장(디버깅과 추적)에서 강조한 "trace" 개념의 구현.
    """
    print("=" * 70)
    print(f"🧪 {test_name}")
    print(f"   질문: \"{query}\"")
    print("=" * 70)

    result = agent.invoke({
        "messages": [{"role": "user", "content": query}]
    })

    # 전체 메시지 흐름을 출력 — ReAct의 각 단계를 확인
    print("\n📋 ReAct 루프 추적 (Trace):")
    print("-" * 50)

    tool_call_count = 0  # 도구 호출 횟수 카운터

    for i, msg in enumerate(result["messages"]):
        msg_type = getattr(msg, 'type', 'unknown')
        content = getattr(msg, 'content', '')

        if msg_type == "human":
            # 사용자 입력
            print(f"  [{i}] 👤 사용자: {content}")

        elif msg_type == "ai":
            # LLM의 판단 (Thought 단계)
            # tool_calls가 있으면 도구 호출을 결정한 것
            tool_calls = getattr(msg, 'tool_calls', [])
            if tool_calls:
                for tc in tool_calls:
                    tool_call_count += 1
                    print(f"  [{i}] 🧠 LLM 판단 → 도구 호출 결정:")
                    print(f"       도구: {tc['name']}")
                    print(f"       인자: {tc['args']}")
            else:
                # tool_calls가 없으면 최종 답변
                print(f"  [{i}] 🤖 최종 답변:")
                # 긴 답변은 줄별로 들여쓰기
                for line in content.split("\n"):
                    if line.strip():
                        print(f"       {line}")

        elif msg_type == "tool":
            # 도구 실행 결과 (Observation 단계)
            tool_name = getattr(msg, 'name', '?')
            print(f"  [{i}] 🔧 도구 결과 ({tool_name}):")
            for line in content.split("\n")[:5]:  # 최대 5줄만 출력
                if line.strip():
                    print(f"       {line}")
            if len(content.split("\n")) > 5:
                print(f"       ... (이하 생략)")

    print(f"\n  📊 총 도구 호출 횟수: {tool_call_count}회")
    print("=" * 70)
    print()

    return result


# ============================================================
# 4단계: 테스트 실행
# ============================================================

# ── 테스트 1: 도구 1개 사용 (단순) ─────────────────────────
# LLM이 search_news 하나만 호출하면 되는 간단한 요청
run_agent(
    "AI 관련 최신 뉴스를 알려줘",
    "테스트 1: 도구 1개 사용 (search_news)"
)


# ── 테스트 2: 도구 2개 연쇄 사용 (핵심!) ────────────────────
# 이론 강의 4장 사례와 동일한 구조:
#   Thought 1: "뉴스를 먼저 검색해야겠다"
#   Action 1:  search_news("AI")
#   Observation 1: 뉴스 결과 수신
#   Thought 2: "이제 영어로 번역해야겠다"
#   Action 2:  translate(뉴스 내용, "english")
#   Observation 2: 번역 결과 수신
#   Thought 3: "정보가 충분하다. 최종 답변을 작성하자"
#   Answer: 번역된 뉴스 제공
run_agent(
    "AI 관련 뉴스를 찾아서 영어로 번역해줘",
    "테스트 2: 도구 2개 연쇄 (search_news → translate)"
)


# ── 테스트 3: 도구 2개 연쇄 사용 (다른 조합) ────────────────
# search_news → summarize_text 조합
run_agent(
    "경제 뉴스를 검색해서 핵심만 요약해줘",
    "테스트 3: 도구 2개 연쇄 (search_news → summarize_text)"
)


# ── 테스트 4: LLM이 도구 없이 직접 답변 ────────────────────
# 도구가 필요 없는 일반 질문 → LLM이 도구를 호출하지 않아야 함
run_agent(
    "오늘 점심 뭐 먹을까?",
    "테스트 4: 도구 불필요 (LLM 직접 답변)"
)


# ── 테스트 5: 3개 도구 모두 사용 가능한 복합 요청 ────────────
run_agent(
    "스포츠 뉴스를 찾아서 요약하고, 그 요약본을 영어로 번역해줘",
    "테스트 5: 도구 3개 연쇄 (search → summarize → translate)"
)


# ============================================================
# 학습 포인트 정리
# ============================================================
print("\n" + "=" * 70)
print("""
📝 이 실습에서 배운 것:

1. @tool 데코레이터로 도구를 정의할 때,
   독스트링(docstring)이 LLM의 도구 선택 기준이 된다.
   → 이론 강의 5장: "도구의 독스트링은 LLM이 읽는 사용 설명서"

2. create_react_agent(llm, tools)로 ReAct 에이전트를 생성하면,
   내부적으로 Thought → Action → Observation 루프가 자동 구성된다.
   → 이론 강의 4장: ReAct 루프

3. LLM은 질문을 분석하여 필요한 도구를 스스로 선택하고,
   여러 도구를 순차적으로 호출할 수 있다.
   → "뉴스 검색 → 번역" 같은 2단계 호출을 LLM이 자율적으로 결정

4. 도구가 필요 없는 질문에는 도구를 호출하지 않고 직접 답한다.
   → should_use_tool 함수가 아니라 LLM이 판단하는 것!
   → 이전에 배운 hasattr(msg, "tool_calls") 체크는
     LLM의 판단을 "읽는" 것이지 판단 자체가 아님

5. 전체 메시지 흐름(trace)을 출력하면
   에이전트의 사고 과정을 디버깅할 수 있다.
   → 이론 강의 10장: "각 단계의 입력-출력을 기록하는 것이 중요"
""")
print("=" * 70)
