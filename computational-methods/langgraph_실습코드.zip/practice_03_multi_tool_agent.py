# ============================================================
# 실습 3: 멀티 도구 ReAct 에이전트 (난이도: ★★★)
# ============================================================
#
# [연결 이론] 이론 강의 4장 "ReAct 루프" (Thought → Action → Observation)
#            이론 강의 5장 "Function Calling — 도구 호출의 원리"
# [연결 실습] LangGraph 실습 강의 7장 "도구(Tool)와 ReAct 에이전트"
#
# 목표:
#   - 3개의 도구(뉴스 검색, 번역, 요약)를 정의
#   - create_react_agent로 ReAct 에이전트 생성
#   - LLM이 스스로 도구를 선택·조합하여 복잡한 요청을 처리하는지 확인
#   - ReAct 루프(Thought → Action → Observation 반복)를 추적
#
# 핵심 확인 사항:
#   "AI 관련 뉴스를 찾아서 영어로 번역해줘"
#   → search_news 호출 → translate 호출 → 최종 답변
#   → LLM이 도구를 2번 연속 호출하는 ReAct 루프 확인
# ============================================================


# ── 환경 설정 ──────────────────────────────────────────────
import os
from dotenv import load_dotenv
load_dotenv()

# ★ 수정 1: GOOGLE_API_KEY와 GEMINI_API_KEY가 동시에 설정되면
#   "Both GOOGLE_API_KEY and GEMINI_API_KEY are set. Using GOOGLE_API_KEY."
#   경고가 출력된다. 원인: langchain-google-genai가 두 키를 모두 감지할 때 발생.
#   해결: GEMINI_API_KEY 값을 GOOGLE_API_KEY로 복사한 뒤,
#         GEMINI_API_KEY 환경변수를 제거하여 중복을 없앤다.
if os.environ.get("GEMINI_API_KEY") and not os.environ.get("GOOGLE_API_KEY"):
    os.environ["GOOGLE_API_KEY"] = os.environ["GEMINI_API_KEY"]
os.environ.pop("GEMINI_API_KEY", None)   # 중복 키 제거

# ★ 수정 2: LangSmith 추적 비활성화
#   "Failed to POST https://api.smith.langchain.com/runs/multipart ... 403 Forbidden"
#   원인: LANGCHAIN_TRACING_V2 환경변수가 기본 활성화된 경우 LangSmith 서버에
#         실행 기록을 전송하려 하지만, API 키가 없거나 권한이 없을 때 403이 발생.
#   해결: 추적을 명시적으로 끈다.
os.environ["LANGCHAIN_TRACING_V2"] = "false"

print("✅ 환경 설정 완료\n")


# ── 패키지 임포트 ──────────────────────────────────────────
# ★ 수정 3: create_react_agent 임포트 경로 수정
#   오류 메시지: "create_react_agent has been moved to `langchain.agents`"
#   원인: LangGraph V1.0부터 create_react_agent가 langgraph.prebuilt에서
#         langchain.agents로 이동했다. langgraph.prebuilt에도 남아 있지만
#         deprecation 경고가 발생한다.
#   해결: langchain.agents에서 임포트한다.
#
#   변경 전: from langgraph.prebuilt import create_react_agent
#   변경 후: from langchain.agents import create_react_agent
from langchain_core.tools import tool
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.agents import create_react_agent          # ← 수정된 임포트
from langchain import hub                                # ← ReAct 프롬프트용
from langchain.agents import AgentExecutor               # ← 에이전트 실행기


# ============================================================
# 1단계: 도구(Tool) 3개 정의
# ============================================================
# 이론 강의 5장 핵심:
#   - @tool 데코레이터로 일반 함수를 "LLM이 호출 가능한 도구"로 변환
#   - 독스트링("""...""")이 LLM의 도구 사용 설명서 역할
#   - 독스트링이 부실하면 LLM이 잘못된 도구를 선택한다

# ── 도구 1: 뉴스 검색 ─────────────────────────────────────
@tool
def search_news(topic: str) -> str:
    """주어진 주제에 대한 최신 뉴스 헤드라인 3개를 검색합니다.
    Args:
        topic: 검색할 뉴스 주제 (예: 'AI', '경제', '스포츠', '정치', '기술')
    Returns:
        관련 뉴스 헤드라인 3개를 포함한 문자열
    """
    news_database = {
        "AI": (
            "1) AI 에이전트 시장 규모 2030년까지 525억 달러 전망\n"
            "2) 구글, Gemini 2.5 모델 공개… 멀티모달 성능 대폭 향상\n"
            "3) 국내 기업 57%가 AI 에이전트 도입 완료"
        ),
        "경제": (
            "1) 한국은행 기준금리 3.25% 동결 결정\n"
            "2) 코스피 3,050선 돌파, 반도체주 강세\n"
            "3) 6월 수출 전년 대비 12.5% 증가"
        ),
        "스포츠": (
            "1) 손흥민 시즌 20호골 달성, 팀 내 득점왕\n"
            "2) 류현진 복귀전 7이닝 1실점 호투\n"
            "3) 2026 밀라노 동계올림픽 한국 선수단 120명 확정"
        ),
        "기술": (
            "1) 삼성전자 3나노 2세대 공정 양산 시작\n"
            "2) 네이버 하이퍼클로바X 기업용 서비스 출시\n"
            "3) 전기차 배터리 에너지 밀도 400Wh/kg 돌파"
        ),
        "정치": (
            "1) 국회 AI 기본법 본회의 통과\n"
            "2) 디지털 플랫폼 규제법 시행 임박\n"
            "3) 공정거래위원회 빅테크 시장 지배력 조사 착수"
        ),
    }

    result = news_database.get(topic)
    if result:
        return f"[{topic} 최신 뉴스]\n{result}"
    for key, value in news_database.items():
        if topic.lower() in key.lower() or key.lower() in topic.lower():
            return f"[{key} 최신 뉴스]\n{value}"
    return f"'{topic}' 관련 뉴스를 찾지 못했습니다. 다른 주제로 검색해 보세요."


# ── 도구 2: 번역 ──────────────────────────────────────────
@tool
def translate(text: str, target_lang: str) -> str:
    """텍스트를 지정된 언어로 번역합니다.
    Args:
        text: 번역할 원본 텍스트
        target_lang: 번역 대상 언어 (예: 'english', 'japanese', 'chinese', 'korean')
    Returns:
        번역된 텍스트
    """
    ko_to_en = {
        "AI 에이전트": "AI Agent",
        "시장 규모": "market size",
        "전망": "forecast",
        "구글": "Google",
        "모델 공개": "model released",
        "성능 대폭 향상": "significant performance improvement",
        "국내 기업": "domestic companies",
        "도입 완료": "adoption completed",
        "기준금리": "benchmark interest rate",
        "동결 결정": "freeze decision",
        "수출": "exports",
        "증가": "increase",
    }

    target = target_lang.lower()

    if target in ["english", "영어", "en"]:
        translated = text
        for ko, en in ko_to_en.items():
            translated = translated.replace(ko, en)
        return f"[번역 결과 (→ English)]\n{translated}"
    elif target in ["japanese", "일본어", "ja"]:
        return f"[번역 결과 (→ 日本語)]\n(일본어 번역 시뮬레이션)\n원문: {text[:100]}..."
    elif target in ["chinese", "중국어", "zh"]:
        return f"[번역 결과 (→ 中文)]\n(중국어 번역 시뮬레이션)\n원문: {text[:100]}..."
    else:
        return f"[번역 결과 (→ {target_lang})]\n(번역 시뮬레이션)\n원문: {text[:100]}..."


# ── 도구 3: 텍스트 요약 ────────────────────────────────────
@tool
def summarize_text(text: str) -> str:
    """긴 텍스트를 핵심 내용 중심으로 짧게 요약합니다.
    Args:
        text: 요약할 원본 텍스트
    Returns:
        2~3문장으로 요약된 텍스트
    """
    lines = [line.strip() for line in text.split("\n") if line.strip()]

    keywords = []
    for line in lines:
        if ")" in line:
            content = line.split(")", 1)[-1].strip()
            keywords.append(content[:15] + "...")
        else:
            keywords.append(line[:20] + "...")

    if keywords:
        summary = f"총 {len(keywords)}개 항목의 요약: " + ", ".join(keywords[:3])
        return f"[요약 결과]\n{summary}"
    else:
        return f"[요약 결과]\n원문 ({len(text)}자)의 핵심: {text[:50]}..."


tools = [search_news, translate, summarize_text]
print("✅ 도구 3개 정의 완료: search_news, translate, summarize_text\n")


# ============================================================
# 2단계: ReAct 에이전트 생성
# ============================================================
# ★ 수정 3 상세 설명:
#   langchain.agents.create_react_agent는 LangGraph의 create_react_agent와
#   사용 방법이 약간 다르다.
#
#   LangGraph 버전 (구):
#     agent = create_react_agent(llm, tools)
#     result = agent.invoke({"messages": [...]})
#
#   langchain.agents 버전 (현재):
#     prompt  = hub.pull("hwchase17/react")   ← ReAct 프롬프트 템플릿
#     agent   = create_react_agent(llm, tools, prompt)
#     executor = AgentExecutor(agent=agent, tools=tools, verbose=True)
#     result  = executor.invoke({"input": "질문"})
#
#   이론 강의 4장의 ReAct 루프(Thought→Action→Observation)는
#   AgentExecutor의 verbose=True 출력으로 그대로 확인할 수 있다.

llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash-lite")

# ReAct 에이전트용 표준 프롬프트 템플릿을 LangChain Hub에서 가져온다
# (인터넷 연결 필요; 오프라인이면 아래 주석 처리 후 로컬 프롬프트 사용)
prompt = hub.pull("hwchase17/react")

# 에이전트 생성 (두뇌 + 도구 + 프롬프트 연결)
agent = create_react_agent(llm, tools, prompt)

# AgentExecutor: 에이전트를 실제로 실행하는 엔진
# verbose=True → Thought/Action/Observation 루프를 터미널에 출력
# handle_parsing_errors=True → LLM 출력 파싱 오류 시 자동 재시도
executor = AgentExecutor(
    agent=agent,
    tools=tools,
    verbose=True,
    handle_parsing_errors=True,
    max_iterations=6,   # 무한 루프 방지: 최대 6회 Thought-Action 반복
)

print("✅ ReAct 에이전트 생성 완료\n")


# ============================================================
# 3단계: 실행 헬퍼 함수
# ============================================================
def run_agent(query: str, test_name: str):
    """
    에이전트에게 요청을 보내고 결과를 출력한다.
    verbose=True 덕분에 ReAct 루프(Thought→Action→Observation)가
    AgentExecutor 내부에서 자동으로 출력된다.
    이론 강의 10장(디버깅과 추적) 개념의 구현.
    """
    print("=" * 70)
    print(f"🧪 {test_name}")
    print(f"   질문: \"{query}\"")
    print("=" * 70)

    result = executor.invoke({"input": query})

    print(f"\n🤖 최종 답변:\n{result['output']}")
    print("=" * 70)
    print()

    return result


# ============================================================
# 4단계: 테스트 실행
# ============================================================

# ── 테스트 1: 도구 1개 사용 (단순) ─────────────────────────
run_agent(
    "AI 관련 최신 뉴스를 알려줘",
    "테스트 1: 도구 1개 사용 (search_news)"
)

# ── 테스트 2: 도구 2개 연쇄 사용 (핵심!) ────────────────────
# Thought 1 → Action: search_news("AI")
# Observation 1 → Thought 2 → Action: translate(뉴스, "english")
# Observation 2 → 최종 답변
run_agent(
    "AI 관련 뉴스를 찾아서 영어로 번역해줘",
    "테스트 2: 도구 2개 연쇄 (search_news → translate)"
)

# ── 테스트 3: 도구 2개 연쇄 사용 (다른 조합) ────────────────
run_agent(
    "경제 뉴스를 검색해서 핵심만 요약해줘",
    "테스트 3: 도구 2개 연쇄 (search_news → summarize_text)"
)

# ── 테스트 4: LLM이 도구 없이 직접 답변 ────────────────────
run_agent(
    "오늘 점심 뭐 먹을까?",
    "테스트 4: 도구 불필요 (LLM 직접 답변)"
)

# ── 테스트 5: 3개 도구 모두 사용 가능한 복합 요청 ────────────
run_agent(
    "스포츠 뉴스를 찾아서 요약하고, 그 요약본을 영어로 번역해줘",
    "테스트 5: 도구 3개 연쇄 (search → summarize → translate)"
)


# ============================================================
# 학습 포인트 정리
# ============================================================
print("\n" + "=" * 70)
print("""
📝 이 실습에서 배운 것:

1. @tool 데코레이터로 도구를 정의할 때,
   독스트링(docstring)이 LLM의 도구 선택 기준이 된다.
   → 이론 강의 5장: "도구의 독스트링은 LLM이 읽는 사용 설명서"

2. langchain.agents.create_react_agent(llm, tools, prompt) +
   AgentExecutor(agent, tools, verbose=True)로 ReAct 에이전트를 실행한다.
   내부적으로 Thought → Action → Observation 루프가 자동 구성된다.
   → 이론 강의 4장: ReAct 루프
   → verbose=True 출력으로 루프 전 과정을 직접 확인할 수 있다.

3. LLM은 질문을 분석하여 필요한 도구를 스스로 선택하고,
   여러 도구를 순차적으로 호출할 수 있다.
   → "뉴스 검색 → 번역" 같은 2단계 호출을 LLM이 자율적으로 결정

4. 도구가 필요 없는 질문에는 도구를 호출하지 않고 직접 답한다.

5. 수정 요약:
   - GEMINI_API_KEY 중복 경고 → 키 통합 후 GEMINI_API_KEY 제거
   - LangSmith 403 오류 → LANGCHAIN_TRACING_V2=false 설정
   - create_react_agent 임포트 → langgraph.prebuilt → langchain.agents
""")
print("=" * 70)
