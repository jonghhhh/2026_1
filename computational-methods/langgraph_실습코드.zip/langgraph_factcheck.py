# ── 필요한 패키지 설치 ─────────────────────────────────────
# pip install langgraph langchain-google-genai python-dotenv requests
# ============================================================
# 실습 4: 네이버 뉴스 기반 팩트체크 파이프라인 (난이도: ★★★)
# ============================================================
#
# [연결 이론] 이론 강의 6장 "워크플로우(Workflow)" — 정해진 순서대로 흐르는 파이프라인
#            실습 3과 비교: 실습 3은 LLM이 스스로 도구를 고르는 "에이전트",
#            이 실습은 우리가 흐름을 직접 짠 "워크플로우"다.
#
# 목표:
#   - 주장(claim) 하나를 입력받아
#   - ① 검색어 추출 → ② 네이버 뉴스 검색(도구) → ③ 요약 → ④ 팩트체크
#     순서로 흐르는 LangGraph 그래프를 직접 조립한다.
#   - 요약된 뉴스를 "근거(evidence)"로 삼아 주장의 진위를 판정한다.
#
# 그래프 구조 (한 방향으로 흐르는 직선형 파이프라인):
#   [START] → [extract_query] → [search_news] → [summarize] → [fact_check] → [END]
#               (검색어 뽑기)     (네이버 뉴스)     (근거 요약)     (진위 판정)
# ============================================================


# ── 환경 설정 ──────────────────────────────────────────────
import os
import re
import requests
from dotenv import load_dotenv
load_dotenv()  # .env 파일을 읽어 그 안의 값들을 환경변수로 등록
os.environ["GOOGLE_API_KEY"] = os.environ["GEMINI_API_KEY"]  # 라이브러리가 찾는 이름으로 복사
print("✅ 환경 설정 완료\n")


# ── 패키지 임포트 ──────────────────────────────────────────
from typing import TypedDict
from langgraph.graph import StateGraph, START, END
from langchain_google_genai import ChatGoogleGenerativeAI


# ── LLM(두뇌) 초기화 ───────────────────────────────────────
# temperature=0 : 팩트체크는 일관성이 중요하므로 창의성을 최소화한다.
llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash-lite", temperature=0)


# ============================================================
# 1단계: 상태(State) 정의 — 그래프 전체에서 공유하는 데이터
# ============================================================
# 노드들이 차례로 이 딕셔너리의 빈 칸을 채워 나간다.
class FactCheckState(TypedDict):
    claim: str       # [입력] 검증할 주장 (예: "한국은행이 기준금리를 인상했다")
    query: str       # extract_query가 채움: 뉴스 검색에 쓸 검색어
    evidence: str    # search_news가 채움: 검색된 뉴스 원문(제목+본문)
    summary: str     # summarize가 채움: 근거로 쓸 요약문
    verdict: str     # fact_check가 채움: 최종 판정 결과


# ── 네이버 뉴스 검색 "도구" 함수 ────────────────────────────
# 실습 3에서는 @tool로 LLM에게 줬지만, 여기서는 우리가 직접 호출하는 일반 함수다.
def naver_news_search(query: str, display: int = 5) -> str:
    """네이버 뉴스 검색 API를 호출해 상위 기사 몇 개의 제목+요약을 문자열로 돌려준다."""
    cid = os.environ.get("NAVER_CLIENT_ID", "")
    secret = os.environ.get("NAVER_CLIENT_SECRET", "")
    if not cid or not secret:
        return "(네이버 API 키 없음 — .env의 NAVER_CLIENT_ID / NAVER_CLIENT_SECRET 확인)"

    url = "https://openapi.naver.com/v1/search/news.json"
    headers = {                          # 네이버는 헤더로 인증한다
        "X-Naver-Client-Id": cid,
        "X-Naver-Client-Secret": secret,
    }
    params = {"query": query, "display": display, "sort": "sim"}  # sim=정확도순

    try:
        r = requests.get(url, headers=headers, params=params, timeout=10)
        r.raise_for_status()             # 200이 아니면 예외 발생
        items = r.json().get("items", [])
    except Exception as e:
        return f"(뉴스 검색 실패: {e})"

    if not items:
        return "(검색 결과 없음)"

    # 결과의 <b></b> 같은 HTML 태그와 특수문자를 제거해 깔끔한 텍스트로 만든다
    def clean(text: str) -> str:
        text = re.sub(r"<[^>]+>", "", text)        # 모든 <...> 태그 제거
        text = text.replace("&quot;", '"').replace("&amp;", "&")
        text = text.replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ")
        return text.strip()

    lines = []
    for i, it in enumerate(items, 1):    # enumerate(..., 1): 번호를 1부터 매김
        title = clean(it.get("title", ""))
        desc = clean(it.get("description", ""))
        lines.append(f"{i}) {title}\n   {desc}")
    return "\n".join(lines)


# ============================================================
# 2단계: 노드(Node) 정의 — 파이프라인의 각 단계
# ============================================================

# ── 노드 1: 주장에서 검색어 뽑기 ────────────────────────────
def extract_query(state: FactCheckState) -> dict:
    claim = state["claim"]
    # LLM에게 "검색에 적합한 핵심 키워드만" 뽑게 한다
    prompt = (
        f"다음 주장을 사실 확인하려고 한다. 네이버 뉴스에서 검색할 핵심 키워드만 "
        f"5단어 이내로, 다른 말 없이 키워드만 출력해라.\n주장: {claim}"
    )
    query = llm.invoke(prompt).content.strip()
    print(f"  [extract_query] 검색어: {query}")
    return {"query": query}              # 바뀐 키만 반환 → LangGraph가 상태에 합쳐 줌


# ── 노드 2: 네이버 뉴스 검색 ────────────────────────────────
def search_news(state: FactCheckState) -> dict:
    evidence = naver_news_search(state["query"], display=5)
    # "1) ", "2) "처럼 줄 맨 앞이 숫자+) 인 줄만 세어 기사 건수를 정확히 표시
    count = len(re.findall(r"(?m)^\d+\)", evidence))
    print(f"  [search_news] 뉴스 {count}건 수집")
    return {"evidence": evidence}


# ── 노드 3: 근거 요약 ──────────────────────────────────────
def summarize(state: FactCheckState) -> dict:
    prompt = (
        "다음 뉴스 검색 결과를 사실 확인의 근거로 쓰려고 한다. "
        "핵심 사실만 3~4문장으로 요약해라. 추측은 빼고 보도된 내용만.\n\n"
        f"{state['evidence']}"
    )
    summary = llm.invoke(prompt).content.strip()
    print(f"  [summarize] 근거 요약 완료")
    return {"summary": summary}


# ── 노드 4: 팩트체크 (요약을 근거로 진위 판정) ──────────────
def fact_check(state: FactCheckState) -> dict:
    prompt = (
        "너는 팩트체커다. 아래 '근거'(뉴스 요약)만을 토대로 '주장'의 진위를 판정해라.\n"
        "형식을 정확히 지켜 출력:\n"
        "판정: [사실 / 거짓 / 불확실] 중 하나\n"
        "이유: 근거에 비춰 1~2문장\n\n"
        f"[주장]\n{state['claim']}\n\n"
        f"[근거]\n{state['summary']}"
    )
    verdict = llm.invoke(prompt).content.strip()
    print(f"  [fact_check] 판정 완료")
    return {"verdict": verdict}


# ============================================================
# 3단계: 그래프 조립 — 노드를 한 줄로 이어 파이프라인 구성
# ============================================================
graph = StateGraph(FactCheckState)

# ① 노드 등록
graph.add_node("extract_query", extract_query)
graph.add_node("search_news", search_news)
graph.add_node("summarize", summarize)
graph.add_node("fact_check", fact_check)

# ② 엣지 연결 — 분기 없이 한 방향으로 쭉 흐른다 (직선형 워크플로우)
graph.add_edge(START, "extract_query")
graph.add_edge("extract_query", "search_news")
graph.add_edge("search_news", "summarize")
graph.add_edge("summarize", "fact_check")
graph.add_edge("fact_check", END)

# ③ 컴파일
app = graph.compile()
print("✅ 팩트체크 그래프 컴파일 완료\n")


# ============================================================
# 4단계: 실행 헬퍼 함수
# ============================================================
def run_factcheck(claim: str):
    print("=" * 70)
    print(f"🔎 검증할 주장: {claim}")
    print("-" * 70)

    # invoke: START부터 END까지 파이프라인을 한 번 실행하고 최종 상태를 돌려준다.
    # query/evidence/summary/verdict는 빈 칸으로 시작 → 노드들이 채운다.
    result = app.invoke({
        "claim": claim,
        "query": "",
        "evidence": "",
        "summary": "",
        "verdict": "",
    })

    print("-" * 70)
    print("📰 근거 요약:")
    print(f"  {result['summary']}")
    print()
    print("⚖️  팩트체크 결과:")
    for line in result["verdict"].split("\n"):
        if line.strip():
            print(f"  {line}")
    print("=" * 70 + "\n")
    return result


# ============================================================
# 5단계: 테스트 실행
# ============================================================
if __name__ == "__main__":
    # 검증하고 싶은 주장을 자유롭게 바꿔서 테스트해 보세요.
    run_factcheck("한국은행이 최근 기준금리를 동결했다.")
    run_factcheck("삼성전자가 3나노 공정 양산을 시작했다.")


# ============================================================
# 학습 포인트 정리
# ============================================================
print("""
📝 이 실습에서 배운 것:

1. 실습 3(에이전트) vs 실습 4(워크플로우)의 차이:
   - 에이전트: LLM이 "어떤 도구를 쓸지" 스스로 판단한다.
   - 워크플로우: 우리가 흐름(검색→요약→판정)을 미리 고정해 둔다.
   → 흐름이 정해져 있고 매번 같은 순서면 워크플로우가 더 예측 가능하고 안정적이다.

2. 외부 API(네이버 뉴스)를 노드 안에서 호출해 실제 데이터를 끌어올 수 있다.
   → LLM의 '기억'이 아니라 '최신 뉴스'를 근거로 삼는 것이 핵심(RAG의 기본 아이디어).

3. 상태(State)의 빈 칸을 노드들이 차례로 채워 나가며 정보가 누적된다.
   claim → query → evidence → summary → verdict 순으로 풍부해진다.

4. "요약을 근거로 판정"하는 구조 덕분에, 판정의 근거를 사람이 함께 확인할 수 있다.
   → 팩트체크에서 중요한 '투명성'을 그래프 구조로 확보한다.
""")
